{
  "version": "1.2",
  "dbname": "imgt_human_ig_c",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "/home/gisela/Projects/Pipelines/test-airrflow/work/19/d57207f9cc332598ed7c76c66dc189/igblast_base/fasta/imgt_human_ig_c.fasta",
  "number-of-letters": 53513,
  "number-of-sequences": 63,
  "last-updated": "2024-11-26T14:48:00",
  "number-of-volumes": 1,
  "bytes-total": 68883,
  "bytes-to-cache": 14391,
  "files": [
    "imgt_human_ig_c.ndb",
    "imgt_human_ig_c.nhr",
    "imgt_human_ig_c.nin",
    "imgt_human_ig_c.nog",
    "imgt_human_ig_c.nos",
    "imgt_human_ig_c.not",
    "imgt_human_ig_c.nsq",
    "imgt_human_ig_c.ntf",
    "imgt_human_ig_c.nto"
  ]
}
