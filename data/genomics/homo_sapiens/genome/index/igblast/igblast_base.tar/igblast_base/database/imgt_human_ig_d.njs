{
  "version": "1.2",
  "dbname": "imgt_human_ig_d",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "/home/gisela/Projects/Pipelines/test-airrflow/work/19/d57207f9cc332598ed7c76c66dc189/igblast_base/fasta/imgt_human_ig_d.fasta",
  "number-of-letters": 1161,
  "number-of-sequences": 47,
  "last-updated": "2024-11-26T14:48:00",
  "number-of-volumes": 1,
  "bytes-total": 54608,
  "bytes-to-cache": 1100,
  "files": [
    "imgt_human_ig_d.ndb",
    "imgt_human_ig_d.nhr",
    "imgt_human_ig_d.nin",
    "imgt_human_ig_d.nog",
    "imgt_human_ig_d.nos",
    "imgt_human_ig_d.not",
    "imgt_human_ig_d.nsq",
    "imgt_human_ig_d.ntf",
    "imgt_human_ig_d.nto"
  ]
}
