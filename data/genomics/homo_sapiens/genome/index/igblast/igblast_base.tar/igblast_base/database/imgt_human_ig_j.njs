{
  "version": "1.2",
  "dbname": "imgt_human_ig_j",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "/home/gisela/Projects/Pipelines/test-airrflow/work/19/d57207f9cc332598ed7c76c66dc189/igblast_base/fasta/imgt_human_ig_j.fasta",
  "number-of-letters": 1593,
  "number-of-sequences": 35,
  "last-updated": "2024-11-26T14:48:00",
  "number-of-volumes": 1,
  "bytes-total": 53200,
  "bytes-to-cache": 1056,
  "files": [
    "imgt_human_ig_j.ndb",
    "imgt_human_ig_j.nhr",
    "imgt_human_ig_j.nin",
    "imgt_human_ig_j.nog",
    "imgt_human_ig_j.nos",
    "imgt_human_ig_j.not",
    "imgt_human_ig_j.nsq",
    "imgt_human_ig_j.ntf",
    "imgt_human_ig_j.nto"
  ]
}
