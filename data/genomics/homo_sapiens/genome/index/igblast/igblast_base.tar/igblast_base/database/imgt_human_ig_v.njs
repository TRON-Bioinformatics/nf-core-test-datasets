{
  "version": "1.2",
  "dbname": "imgt_human_ig_v",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "/home/gisela/Projects/Pipelines/test-airrflow/work/19/d57207f9cc332598ed7c76c66dc189/igblast_base/fasta/imgt_human_ig_v.fasta",
  "number-of-letters": 207951,
  "number-of-sequences": 711,
  "last-updated": "2024-11-26T14:48:00",
  "number-of-volumes": 1,
  "bytes-total": 195731,
  "bytes-to-cache": 61285,
  "files": [
    "imgt_human_ig_v.ndb",
    "imgt_human_ig_v.nhr",
    "imgt_human_ig_v.nin",
    "imgt_human_ig_v.nog",
    "imgt_human_ig_v.nos",
    "imgt_human_ig_v.not",
    "imgt_human_ig_v.nsq",
    "imgt_human_ig_v.ntf",
    "imgt_human_ig_v.nto"
  ]
}
