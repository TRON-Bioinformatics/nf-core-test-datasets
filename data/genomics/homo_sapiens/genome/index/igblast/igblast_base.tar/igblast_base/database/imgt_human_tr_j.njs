{
  "version": "1.2",
  "dbname": "imgt_human_tr_j",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "/home/gisela/Projects/Pipelines/test-airrflow/work/19/d57207f9cc332598ed7c76c66dc189/igblast_base/fasta/imgt_human_tr_j.fasta",
  "number-of-letters": 5675,
  "number-of-sequences": 97,
  "last-updated": "2024-11-26T14:48:00",
  "number-of-volumes": 1,
  "bytes-total": 60406,
  "bytes-to-cache": 2862,
  "files": [
    "imgt_human_tr_j.ndb",
    "imgt_human_tr_j.nhr",
    "imgt_human_tr_j.nin",
    "imgt_human_tr_j.nog",
    "imgt_human_tr_j.nos",
    "imgt_human_tr_j.not",
    "imgt_human_tr_j.nsq",
    "imgt_human_tr_j.ntf",
    "imgt_human_tr_j.nto"
  ]
}
