{
  "version": "1.2",
  "dbname": "imgt_mouse_ig_d",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "/home/gisela/Projects/Pipelines/test-airrflow/work/19/d57207f9cc332598ed7c76c66dc189/igblast_base/fasta/imgt_mouse_ig_d.fasta",
  "number-of-letters": 1141,
  "number-of-sequences": 61,
  "last-updated": "2024-11-26T14:48:00",
  "number-of-volumes": 1,
  "bytes-total": 55900,
  "bytes-to-cache": 1278,
  "files": [
    "imgt_mouse_ig_d.ndb",
    "imgt_mouse_ig_d.nhr",
    "imgt_mouse_ig_d.nin",
    "imgt_mouse_ig_d.nog",
    "imgt_mouse_ig_d.nos",
    "imgt_mouse_ig_d.not",
    "imgt_mouse_ig_d.nsq",
    "imgt_mouse_ig_d.ntf",
    "imgt_mouse_ig_d.nto"
  ]
}
