{
  "version": "1.2",
  "dbname": "imgt_mouse_ig_j",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "/home/gisela/Projects/Pipelines/test-airrflow/work/19/d57207f9cc332598ed7c76c66dc189/igblast_base/fasta/imgt_mouse_ig_j.fasta",
  "number-of-letters": 1101,
  "number-of-sequences": 26,
  "last-updated": "2024-11-26T14:48:00",
  "number-of-volumes": 1,
  "bytes-total": 52216,
  "bytes-to-cache": 824,
  "files": [
    "imgt_mouse_ig_j.ndb",
    "imgt_mouse_ig_j.nhr",
    "imgt_mouse_ig_j.nin",
    "imgt_mouse_ig_j.nog",
    "imgt_mouse_ig_j.nos",
    "imgt_mouse_ig_j.not",
    "imgt_mouse_ig_j.nsq",
    "imgt_mouse_ig_j.ntf",
    "imgt_mouse_ig_j.nto"
  ]
}
