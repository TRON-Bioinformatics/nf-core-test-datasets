{
  "version": "1.2",
  "dbname": "imgt_mouse_ig_v",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "/home/gisela/Projects/Pipelines/test-airrflow/work/19/d57207f9cc332598ed7c76c66dc189/igblast_base/fasta/imgt_mouse_ig_v.fasta",
  "number-of-letters": 248123,
  "number-of-sequences": 856,
  "last-updated": "2024-11-26T14:48:00",
  "number-of-volumes": 1,
  "bytes-total": 224999,
  "bytes-to-cache": 73077,
  "files": [
    "imgt_mouse_ig_v.ndb",
    "imgt_mouse_ig_v.nhr",
    "imgt_mouse_ig_v.nin",
    "imgt_mouse_ig_v.nog",
    "imgt_mouse_ig_v.nos",
    "imgt_mouse_ig_v.not",
    "imgt_mouse_ig_v.nsq",
    "imgt_mouse_ig_v.ntf",
    "imgt_mouse_ig_v.nto"
  ]
}
