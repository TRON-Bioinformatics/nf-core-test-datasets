{
  "version": "1.2",
  "dbname": "imgt_mouse_tr_c",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "/home/gisela/Projects/Pipelines/test-airrflow/work/19/d57207f9cc332598ed7c76c66dc189/igblast_base/fasta/imgt_mouse_tr_c.fasta",
  "number-of-letters": 4421,
  "number-of-sequences": 9,
  "last-updated": "2024-11-26T14:48:00",
  "number-of-volumes": 1,
  "bytes-total": 51457,
  "bytes-to-cache": 1503,
  "files": [
    "imgt_mouse_tr_c.ndb",
    "imgt_mouse_tr_c.nhr",
    "imgt_mouse_tr_c.nin",
    "imgt_mouse_tr_c.nog",
    "imgt_mouse_tr_c.nos",
    "imgt_mouse_tr_c.not",
    "imgt_mouse_tr_c.nsq",
    "imgt_mouse_tr_c.ntf",
    "imgt_mouse_tr_c.nto"
  ]
}
