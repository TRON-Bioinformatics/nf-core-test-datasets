{
  "version": "1.2",
  "dbname": "imgt_mouse_tr_d",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "/home/gisela/Projects/Pipelines/test-airrflow/work/19/d57207f9cc332598ed7c76c66dc189/igblast_base/fasta/imgt_mouse_tr_d.fasta",
  "number-of-letters": 60,
  "number-of-sequences": 5,
  "last-updated": "2024-11-26T14:48:00",
  "number-of-volumes": 1,
  "bytes-total": 49924,
  "bytes-to-cache": 300,
  "files": [
    "imgt_mouse_tr_d.ndb",
    "imgt_mouse_tr_d.nhr",
    "imgt_mouse_tr_d.nin",
    "imgt_mouse_tr_d.nog",
    "imgt_mouse_tr_d.nos",
    "imgt_mouse_tr_d.not",
    "imgt_mouse_tr_d.nsq",
    "imgt_mouse_tr_d.ntf",
    "imgt_mouse_tr_d.nto"
  ]
}
