{
  "version": "1.2",
  "dbname": "imgt_mouse_tr_j",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "/home/gisela/Projects/Pipelines/test-airrflow/work/19/d57207f9cc332598ed7c76c66dc189/igblast_base/fasta/imgt_mouse_tr_j.fasta",
  "number-of-letters": 5590,
  "number-of-sequences": 96,
  "last-updated": "2024-11-26T14:48:00",
  "number-of-volumes": 1,
  "bytes-total": 60290,
  "bytes-to-cache": 2826,
  "files": [
    "imgt_mouse_tr_j.ndb",
    "imgt_mouse_tr_j.nhr",
    "imgt_mouse_tr_j.nin",
    "imgt_mouse_tr_j.nog",
    "imgt_mouse_tr_j.nos",
    "imgt_mouse_tr_j.not",
    "imgt_mouse_tr_j.nsq",
    "imgt_mouse_tr_j.ntf",
    "imgt_mouse_tr_j.nto"
  ]
}
