{
  "version": "1.2",
  "dbname": "imgt_mouse_tr_v",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "/home/gisela/Projects/Pipelines/test-airrflow/work/19/d57207f9cc332598ed7c76c66dc189/igblast_base/fasta/imgt_mouse_tr_v.fasta",
  "number-of-letters": 107025,
  "number-of-sequences": 387,
  "last-updated": "2024-11-26T14:48:00",
  "number-of-volumes": 1,
  "bytes-total": 128075,
  "bytes-to-cache": 31875,
  "files": [
    "imgt_mouse_tr_v.ndb",
    "imgt_mouse_tr_v.nhr",
    "imgt_mouse_tr_v.nin",
    "imgt_mouse_tr_v.nog",
    "imgt_mouse_tr_v.nos",
    "imgt_mouse_tr_v.not",
    "imgt_mouse_tr_v.nsq",
    "imgt_mouse_tr_v.ntf",
    "imgt_mouse_tr_v.nto"
  ]
}
